<?php
// login.php - Handling user login (with role-based logic)

include 'db_connection.php';  // Include database connection file
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM students WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $user = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];  // Set user session
            $_SESSION['username'] = $user['username'];  // Store username in session
            $_SESSION['role'] = $user['role'];  // Store user role in session
            
            // Store a flag in session to indicate successful login (for the notification)
            $_SESSION['logged_in'] = true;

            // Redirect based on user role
            if ($user['role'] == 'admin') {
                header("Location: admin_dashboard.php");  // Redirect to admin dashboard if admin
            } else {
                header("Location: dashboard.php");  // Redirect to student dashboard if student
            }
            exit(); // Ensure that further code is not executed after redirect
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login</title>
    <link rel="stylesheet" href="regi.css">
</head>
<body>
   
    <form method="POST">
        <label for="username">Username</label>
        <input type="text" name="username" required><br>
        
        <label for="password">Password</label>
        <input type="password" name="password" required><br>
        
        <button type="submit">Login</button>
    </form>

    <!-- Notification for Successful Login -->
    <div id="loginNotification" class="notification">
        <span id="notificationMessage">You have logged in successfully!</span>
    </div>

    <script>
        // Function to show the login success notification
        function showLoginNotification() {
            var notification = document.getElementById("loginNotification");
            var message = document.getElementById("notificationMessage");

            // Display the notification only if not shown already
            if (!sessionStorage.getItem("notificationShown")) {
                // Change the message if needed (e.g., based on username)
                message.innerHTML = "You have logged in successfully!";

                // Display the notification
                notification.classList.add("show");

                // After 3 seconds, hide the notification
                setTimeout(function() {
                    notification.classList.add("fade-out");
                    setTimeout(function() {
                        notification.classList.remove("show", "fade-out");
                    }, 500); // Wait for fade-out to complete before removing the class
                }, 3000); // Hide after 3 seconds

                // Set the session storage flag to indicate the notification has been shown
                sessionStorage.setItem("notificationShown", "true");
            }
        }

        // Check if the user has logged in (based on session variable)
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            // Call this function if the user is logged in
            showLoginNotification();
        <?php endif; ?>
    </script>

</body>
</html>
