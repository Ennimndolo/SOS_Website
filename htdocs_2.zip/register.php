<?php
// register.php - Updated form with profile picture input and role selection

include 'db_connection.php';  // Database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);  // Encrypt password
    $role = $_POST['role'];  // Get selected role (student or admin)
    
    // Handle profile picture upload
    $profile_pic = 'default-profile.png';  // Default profile picture
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $profile_pic_name = $_FILES['profile_pic']['name'];
        $profile_pic_temp = $_FILES['profile_pic']['tmp_name'];
        $profile_pic_ext = pathinfo($profile_pic_name, PATHINFO_EXTENSION);
        
        // Check if the uploaded file is an image
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array(strtolower($profile_pic_ext), $allowed_extensions)) {
            $profile_pic = uniqid() . '.' . $profile_pic_ext;
            move_uploaded_file($profile_pic_temp, 'uploads/' . $profile_pic);  // Move the uploaded file to the 'uploads' folder
        } else {
            echo "Invalid file type. Only images are allowed.";
            exit();
        }
    }

    // Set registration status and period
    $registration_status = 'Not Registered';  // Default status
    $registration_period = 'TBD';  // Default period

    // Insert student data into the database
    $query = "INSERT INTO students (full_name, email, phone_number, username, password, registration_status, registration_period, profile_pic, role) 
              VALUES ('$full_name', '$email', '$phone_number', '$username', '$password', '$registration_status', '$registration_period', '$profile_pic', '$role')";
    
    if (mysqli_query($conn, $query)) {
        echo "Registration successful!";
        header("Location: login.php");  // Redirect to login page
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Registration</title>
    <link rel="stylesheet" href="regi.css">
</head>
<body>
    <h2>Student Registration</h2>
    <form method="POST" enctype="multipart/form-data">
        <label for="full_name">Full Name</label>
        <input type="text" name="full_name" required><br>
        
        <label for="email">Email</label>
        <input type="email" name="email" required><br>
        
        <label for="phone_number">Phone Number</label>
        <input type="text" name="phone_number" required><br>
        
        <label for="username">Username</label>
        <input type="text" name="username" required><br>
        
        <label for="password">Password</label>
        <input type="password" name="password" required><br>

        <!-- Role selection -->
        <label for="role">Role</label>
        <select name="role" required>
            <option value="student">Student</option>
            <option value="admin">Admin</option>
        </select><br>

        <!-- Profile Picture upload -->
        <label for="profile_pic">Profile Picture</label>
        <input type="file" name="profile_pic" accept="image/*"><br>
        
        <button type="submit">Register</button>
    </form>
</body>
</html>
