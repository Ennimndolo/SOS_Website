<?php
// login.php - Handling user login (with role-based logic)

include 'db_connection.php';  // Include database connection file
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM students WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $user = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];  // Set user session
            $_SESSION['username'] = $user['username'];  // Store username in session
            $_SESSION['role'] = $user['role'];  // Store user role in session
            
            if ($user['role'] == 'admin') {
                header("Location: admin_dashboard.php");  // Redirect to admin dashboard if admin
            } else {
                header("Location: dashboard.php");  // Redirect to student dashboard if student
            }
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login</title>
    <link rel="stylesheet" href="regi.css">
</head>
<body>
    <h2>Student Login</h2>
    <form method="POST">
        <label for="username">Username</label>
        <input type="text" name="username" required><br>
        
        <label for="password">Password</label>
        <input type="password" name="password" required><br>
        
        <button type="submit">Login</button>
    </form>
</body>
</html>
