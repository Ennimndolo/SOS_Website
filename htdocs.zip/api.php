<?php
function checkFeesStatus($studentId) {
    $apiUrl = "https://api.bank.com/check-payment";  // Placeholder URL for the bank API
    $apiKey = "YOUR_API_KEY";  // You would get this from the bank

    // Prepare data for the API request
    $data = array(
        'student_id' => $studentId
    );

    // Set up cURL to make the API call
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    // Execute the API request
    $response = curl_exec($ch);
    curl_close($ch);

    // Parse and return the response
    $result = json_decode($response, true);
    return $result;  // Returns an array with the payment status
}
?>
